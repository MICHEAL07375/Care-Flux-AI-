"""SQLite persistence (dataset, resource configuration, small key/value meta)."""
import json
import os
import sqlite3
from contextlib import closing
from pathlib import Path
import pandas as pd
from .models import Resources


def db_path() -> str:
    default = Path(__file__).resolve().parent.parent / "data" / "hospopt.db"
    return os.environ.get("HOSPOPT_DB", str(default))


def _conn() -> sqlite3.Connection:
    p = db_path()
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(p)


def init() -> None:
    with closing(_conn()) as c:
        c.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)")
        c.commit()


def get_meta(key: str, default=None):
    with closing(_conn()) as c:
        row = c.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return row[0] if row else default


def set_meta(key: str, value: str) -> None:
    with closing(_conn()) as c:
        c.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (key, value))
        c.commit()


def load_resources() -> Resources:
    raw = get_meta("resources")
    if not raw:
        return Resources()
    try:
        return Resources.from_dict(json.loads(raw))
    except Exception:
        return Resources()


def save_resources(res: Resources) -> None:
    set_meta("resources", json.dumps(res.to_dict()))


def load_data():
    with closing(_conn()) as c:
        try:
            df = pd.read_sql_query("SELECT * FROM daily_data ORDER BY date", c)
        except Exception:
            return None
    if df.empty:
        return None
    df["date"] = pd.to_datetime(df["date"])
    return df


def save_data(df: pd.DataFrame, source: str) -> None:
    out = df.copy()
    out["date"] = pd.to_datetime(out["date"]).dt.strftime("%Y-%m-%d")
    with closing(_conn()) as c:
        out.to_sql("daily_data", c, if_exists="replace", index=False)
        c.commit()
    set_meta("data_source", source)
