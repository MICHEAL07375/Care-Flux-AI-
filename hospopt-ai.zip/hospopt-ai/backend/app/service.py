"""Application service: owns the dataset, trained models, resource config and orchestrates
forecast -> scenario -> optimisation. No web-framework code here, so it is directly testable."""
import io
import threading
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from . import store
from .config import (TARGETS, KEY_OF, LABELS, MAX_HORIZON, MIN_ROWS, REQUIRED_COLUMNS, STANDARD_COLUMNS,
                     SURGE_COUPLING, FLU_COUPLING, HIGH_UTIL, CRITICAL_UTIL)
from .data_gen import generate_synthetic
from .forecast import DemandForecaster, ENGINE_NAME
from .models import Resources, Scenario, adjust_resources
from .optimizer import plan_day, staff_need, status_of, available_solver

KEYS = ["beds", "icu", "er", "or", "nurses", "doctors"]


def scenario_multipliers(sc: Scenario) -> dict:
    s, f = sc.emergency_surge_pct / 100.0, sc.flu_season_pct / 100.0
    return {k: 1.0 + SURGE_COUPLING[k] * s + FLU_COUPLING[k] * f for k in SURGE_COUPLING}


def parse_csv(content: bytes) -> pd.DataFrame:
    try:
        df = pd.read_csv(io.BytesIO(content))
    except Exception as e:
        raise ValueError(f"Could not parse CSV: {e}")
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"CSV is missing required column(s): {', '.join(missing)}. "
                         f"Required: {', '.join(REQUIRED_COLUMNS)}")
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.dropna(subset=["date"])
    if df.empty:
        raise ValueError("No valid dates found in the 'date' column.")
    num = [c for c in REQUIRED_COLUMNS if c != "date"]
    for c in num:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.sort_values("date").drop_duplicates("date", keep="last").set_index("date")
    full = df.reindex(pd.date_range(df.index.min(), df.index.max(), freq="D"))
    full[num] = full[num].interpolate(limit=7, limit_direction="both")
    if full[num].isna().any().any():
        raise ValueError("Too many missing/non-numeric values (gaps longer than 7 days).")
    full[num] = full[num].clip(lower=0)
    for c in STANDARD_COLUMNS:
        if c != "date" and c not in full.columns:
            full[c] = np.nan
    full = full.reset_index(names="date")
    if len(full) < MIN_ROWS:
        raise ValueError(f"Need at least {MIN_ROWS} consecutive days of data; got {len(full)}.")
    return full[STANDARD_COLUMNS]


class Engine:
    def __init__(self):
        self.lock = threading.RLock()
        store.init()
        self.resources = store.load_resources()
        df = store.load_data()
        source = store.get_meta("data_source", "synthetic")
        stale = df is not None and source == "synthetic" and \
            pd.Timestamp(df["date"].max()).date() < (pd.Timestamp.today().normalize() - pd.Timedelta(days=1)).date()
        if df is None or len(df) < MIN_ROWS or stale:
            df, source = generate_synthetic(), "synthetic"
            store.save_data(df, source)
        self.data, self.source = df, source
        self._train(self.data)

    # ------------------------------------------------------------------ training / data
    def _train(self, df: pd.DataFrame) -> None:
        f = DemandForecaster().fit(df)          # raises before touching live state
        with self.lock:
            self.forecaster, self.base = f, f.predict(MAX_HORIZON)
            self.trained_at = datetime.now(timezone.utc).isoformat(timespec="seconds")

    def retrain(self) -> dict:
        self._train(self.data)
        return self.model_info()

    def replace_data(self, df: pd.DataFrame, source: str) -> dict:
        self._train(df)                           # validate first; keep old data if it fails
        with self.lock:
            self.data, self.source = df, source
            store.save_data(df, source)
        return self.health()

    def upload_csv(self, content: bytes) -> dict:
        return self.replace_data(parse_csv(content), "upload")

    def reset_synthetic(self) -> dict:
        return self.replace_data(generate_synthetic(), "synthetic")

    def export_csv(self, days: int = 90) -> str:
        return self.data.tail(days).to_csv(index=False, date_format="%Y-%m-%d")

    def update_resources(self, patch: dict) -> dict:
        with self.lock:
            self.resources = Resources.from_dict({**self.resources.to_dict(), **patch})
            store.save_resources(self.resources)
            return self.resources.to_dict()

    # ------------------------------------------------------------------ read models
    def health(self) -> dict:
        return {"status": "ok", "forecast_engine": ENGINE_NAME, "solver": available_solver(),
                "data_source": self.source, "data_rows": int(len(self.data)),
                "last_date": self.data["date"].max().strftime("%Y-%m-%d"), "trained_at": self.trained_at}

    def model_info(self) -> dict:
        return {"engine": ENGINE_NAME, "trained_at": self.trained_at, "data_source": self.source,
                "metrics": {KEY_OF[t]: m for t, m in self.forecaster.metrics.items()},
                "method": "Gradient-boosted trees on deviation from trailing 7-day mean, recursive multi-step; "
                          "metrics from 3 rolling-origin 7-day backtests vs seasonal-naive."}

    def history(self, days: int = 14) -> dict:
        d = self.data.tail(days)
        return {"dates": d["date"].dt.strftime("%Y-%m-%d").tolist(),
                "series": {KEY_OF[t]: [float(x) for x in d[t]] for t in TARGETS}}

    def overview(self) -> dict:
        r, last = self.resources, self.data.iloc[-1]
        icu, beds, er, orh = (float(last[t]) for t in ("icu_occupied", "beds_occupied", "emergency_cases", "or_hours_used"))
        nn, dn = staff_need(icu, beds, er, r)
        rows = [("beds", beds, r.general_beds), ("icu", icu, r.icu_beds), ("er", er, r.er_capacity),
                ("or", orh, r.or_hours), ("nurses", nn, r.nurses), ("doctors", dn, r.doctors)]
        kpis = [{"key": k, "label": LABELS[k], "value": round(v, 1), "capacity": round(float(c), 1),
                 "util": round(v / max(c, 1e-9), 3), "status": status_of(v / max(c, 1e-9))} for k, v, c in rows]
        return {"as_of": last["date"].strftime("%Y-%m-%d"), "kpis": kpis, "resources": r.to_dict()}

    # ------------------------------------------------------------------ forecast / optimise / simulate
    def _scenario_forecast(self, horizon: int, sc: Scenario) -> dict:
        mult = scenario_multipliers(sc)
        dates = [(self.forecaster.last_date + pd.Timedelta(days=i + 1)) for i in range(horizon)]
        series = {}
        for t in TARGETS:
            k, m = KEY_OF[t], mult[KEY_OF[t]]
            series[k] = {part: [round(float(x) * m, 2) for x in arr[:horizon]] for part, arr in self.base[t].items()}
        return {"dates": dates, "series": series, "multipliers": {k: round(v, 3) for k, v in mult.items()}}

    def forecast(self, horizon: int, sc: Scenario) -> dict:
        self._check_horizon(horizon)
        res = adjust_resources(self.resources, sc)
        fc = self._scenario_forecast(horizon, sc)
        out = {"dates": [d.strftime("%Y-%m-%d") for d in fc["dates"]], "series": fc["series"],
               "multipliers": fc["multipliers"], "resources": res.to_dict()}
        return out

    def optimize(self, horizon: int, sc: Scenario, patch: dict | None = None) -> dict:
        self._check_horizon(horizon)
        with self.lock:
            base_res = Resources.from_dict({**self.resources.to_dict(), **(patch or {})})
            res = adjust_resources(base_res, sc)
            fc = self._scenario_forecast(horizon, sc)
        plans = []
        for i, ts in enumerate(fc["dates"]):
            d = {k: fc["series"][k]["values"][i] for k in ("icu", "beds", "er", "or")}
            plans.append(plan_day(i + 1, ts.strftime("%Y-%m-%d"), ts.strftime("%a"), d, res))
        util = {k: [p["utilization"][k] for p in plans] for k in KEYS}
        status = {k: status_of(max(v)) for k, v in util.items()}
        peak = max(range(len(plans)), key=lambda i: (plans[i]["risk"], -i))
        return {
            "horizon": horizon, "scenario": sc.to_dict(), "resources": res.to_dict(),
            "forecast": {"dates": [p["date"] for p in plans], "series": fc["series"], "utilization": util,
                         "status": status, "multipliers": fc["multipliers"]},
            "plans": plans, "peak_day": peak, "alerts": self._alerts(plans, res),
            "summary": self._summary(plans[peak], res),
            "impact": self._impact(plans),
        }

    def simulate(self, horizon: int, sc: Scenario, patch: dict | None = None) -> dict:
        base = self.optimize(horizon, Scenario(), patch)
        scen = base if sc.is_baseline else self.optimize(horizon, sc, patch)
        cmp_rows = []
        for k in KEYS:
            b, s = max(base["forecast"]["utilization"][k]), max(scen["forecast"]["utilization"][k])
            cmp_rows.append({"key": k, "label": LABELS[k], "baseline_peak_util": round(b, 3),
                             "scenario_peak_util": round(s, 3), "delta_pts": round((s - b) * 100, 1),
                             "baseline_status": status_of(b), "scenario_status": status_of(s)})
        return {"baseline": base, "scenario": scen, "comparison": cmp_rows}

    # ------------------------------------------------------------------ narrative helpers
    @staticmethod
    def _check_horizon(h: int) -> None:
        if not 1 <= h <= MAX_HORIZON:
            raise ValueError(f"horizon must be between 1 and {MAX_HORIZON}")

    @staticmethod
    def _alerts(plans, res) -> list:
        out = []
        for k in KEYS:
            us = [p["utilization"][k] for p in plans]
            peak = max(us)
            sev = status_of(peak)
            if sev == "OK":
                continue
            thr = CRITICAL_UTIL if sev == "CRITICAL" else HIGH_UTIL
            i = next(j for j, u in enumerate(us) if u >= thr)
            when = "tomorrow" if i == 0 else f"in {i + 1} days"
            if k in ("nurses", "doctors") and peak > 1:
                need = plans[i]["staff_required"][k]
                have = res.nurses if k == "nurses" else res.doctors
                msg = f"{LABELS[k][:-1]} shortage predicted {when}: need {need:.0f}, have {have}"
            elif peak > 1:
                msg = f"{LABELS[k]} over capacity {when} ({peak:.0%} of capacity)"
            else:
                msg = f"{LABELS[k]} {sev.lower()} {when} ({peak:.0%} utilisation)"
            out.append({"resource": k, "severity": sev, "day": i + 1, "message": msg, "peak_util": round(peak, 3)})
        out.sort(key=lambda a: (a["severity"] != "CRITICAL", a["day"]))
        return out

    @staticmethod
    def _summary(p, res) -> str:
        worst = max(p["utilization"], key=p["utilization"].get)
        acts = [a["text"] for a in p["actions"] if a["type"] not in ("reserve", "none", "monitor")][:3]
        head = (f"Peak pressure {'tomorrow' if p['day'] == 1 else 'on ' + p['weekday'] + ' ' + p['date']}: "
                f"{LABELS[worst]} at {p['utilization'][worst]:.0%}.")
        tail = (" Recommended: " + "; ".join(acts) + ".") if acts else (
            " Demand fits within capacity but headroom is thin - pre-position staff and keep monitoring."
            if p["status"] != "OK" else " No corrective action is required.")
        return head + tail

    @staticmethod
    def _impact(plans) -> dict:
        tot = lambda key: round(sum(sum(p[key].values()) for p in plans), 1)
        return {"shortfall_before": tot("baseline_gap"), "shortfall_after": tot("after_gap"),
                "days_critical": sum(p["status"] == "CRITICAL" for p in plans),
                "interventions": sum(sum(p["levers"].values()) for p in plans)}
