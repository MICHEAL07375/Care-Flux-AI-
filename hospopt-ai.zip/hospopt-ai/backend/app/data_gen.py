"""Synthetic hospital dataset (no real patient data). Includes weekly + seasonal patterns and a
recent demand ramp so the demo shows genuine capacity pressure."""
from datetime import date
import numpy as np
import pandas as pd
from .config import STANDARD_COLUMNS


def _ar1(n: int, phi: float, sigma: float, rng) -> np.ndarray:
    e = rng.normal(0, sigma, n)
    x = np.zeros(n)
    for i in range(1, n):
        x[i] = phi * x[i - 1] + e[i]
    return x


def generate_synthetic(days: int = 180, end_date=None, seed: int = 7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    end = pd.Timestamp(end_date or date.today()).normalize()
    dates = pd.date_range(end=end, periods=days, freq="D")
    t = np.arange(days)
    dow = dates.dayofweek.to_numpy()                      # Mon=0
    doy = dates.dayofyear.to_numpy()
    season = np.sin(2 * np.pi * (doy - 30) / 365.25)      # winter peak
    ramp = np.clip((t - (days - 24)) / 24.0, 0, 1) ** 1.2  # demand building in the last ~3 weeks

    wk_er = np.array([4, 1, 0, 0, 2, 4, 3])[dow]
    wk_beds = np.array([5, 4, 2, 0, -1, -4, -3])[dow]
    wk_icu = np.array([1, 1, 0, 0, 0, -1, -1])[dow]
    wk_or = np.array([4, 5, 3, 2, 1, -9, -12])[dow]

    er = 36 + wk_er + 2 * season + 15 * ramp + _ar1(days, 0.5, 2.5, rng)
    beds = 100 + wk_beds + 3 * season + 30 * ramp + _ar1(days, 0.85, 2.0, rng)
    icu = 19 + wk_icu + 1 * season + 12.5 * ramp + _ar1(days, 0.8, 0.9, rng)
    orh = 36 + wk_or + 4 * ramp + 0.15 * (er - 36) + _ar1(days, 0.4, 1.5, rng)

    beds = np.clip(np.round(beds), 40, 148)
    icu = np.clip(np.round(icu), 6, 30)
    er = np.clip(np.round(er), 10, None)
    orh = np.clip(np.round(orh, 1), 4, None)
    avg_stay = np.clip(4.6 + rng.normal(0, 0.2, days), 3.8, 5.5).round(2)

    df = pd.DataFrame({
        "date": dates,
        "admissions": np.round(beds / avg_stay + rng.normal(0, 2, days)).astype(int),
        "emergency_cases": er.astype(int),
        "icu_admissions": np.clip(np.round(icu / 3.4 + rng.normal(0, 1, days)), 0, None).astype(int),
        "icu_occupied": icu.astype(int),
        "beds_occupied": beds.astype(int),
        "avg_stay": avg_stay,
        "doctors_available": np.clip(np.round(rng.normal(25, 1, days)), 21, 28).astype(int),
        "nurses_available": np.clip(np.round(rng.normal(52, 2.5, days)), 44, 60).astype(int),
        "or_hours_used": orh,
        "scheduled_surgeries": np.round(orh / 2.3).astype(int),
        "beds_total": 150,
        "icu_total": 30,
    })
    return df[STANDARD_COLUMNS]
