"""Demand forecasting.

One gradient-boosted model per series (XGBoost when installed, scikit-learn otherwise).
The model predicts the *deviation from the trailing 7-day mean*, which lets tree models follow
trends they never saw in training. Multi-day forecasts are produced recursively.
Rolling-origin backtests give honest accuracy numbers (vs a seasonal-naive baseline) and the
residual spread that drives the 80 % prediction band.
"""
import math
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from .config import TARGETS, MAX_HORIZON, MIN_ROWS

try:  # optional, preferred
    from xgboost import XGBRegressor
    HAS_XGB = True
except Exception:  # pragma: no cover
    HAS_XGB = False

LOOKBACK = 14
ENGINE_NAME = "xgboost" if HAS_XGB else "sklearn-gradient-boosting"


def _new_model():
    if HAS_XGB:
        return XGBRegressor(n_estimators=250, max_depth=3, learning_rate=0.05, subsample=0.9,
                            colsample_bytree=0.9, min_child_weight=2, random_state=7,
                            n_jobs=1, verbosity=0)
    return GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.05,
                                     subsample=0.9, random_state=7)


def _features(hist, ts: pd.Timestamp) -> list:
    h = np.asarray(hist[-LOOKBACK:], dtype=float)
    m7 = h[-7:].mean()
    doy = ts.dayofyear
    dow = [1.0 if ts.dayofweek == i else 0.0 for i in range(7)]
    return [
        h[-1] - m7, h[-2] - m7, h[-3] - m7, h[-7] - m7,        # recent shape
        m7,                                                      # level
        h[:7].mean() - m7,                                       # week-over-week drift
        h[-7:].std(),                                            # volatility
        (h[-1] - h[-7]) / 6.0,                                   # short-term slope
        math.sin(2 * math.pi * doy / 365.25), math.cos(2 * math.pi * doy / 365.25),
        *dow,
    ]


def _xy(y: np.ndarray, dates: pd.DatetimeIndex):
    X, T = [], []
    for i in range(LOOKBACK, len(y)):
        X.append(_features(y[:i], dates[i]))
        T.append(y[i] - y[i - 7:i].mean())
    return np.asarray(X), np.asarray(T)


def _recursive(model, y, last_date: pd.Timestamp, horizon: int) -> np.ndarray:
    hist, out = list(map(float, y)), []
    for k in range(horizon):
        ts = last_date + pd.Timedelta(days=k + 1)
        base = float(np.mean(hist[-7:]))
        yhat = max(0.0, base + float(model.predict(np.asarray([_features(hist, ts)]))[0]))
        hist.append(yhat)
        out.append(yhat)
    return np.asarray(out)


class DemandForecaster:
    def __init__(self):
        self.models, self.series, self.sigma, self.metrics = {}, {}, {}, {}
        self.last_date = None
        self.engine = ENGINE_NAME

    def fit(self, df: pd.DataFrame) -> "DemandForecaster":
        df = df.sort_values("date").reset_index(drop=True)
        n = len(df)
        if n < MIN_ROWS:
            raise ValueError(f"Need at least {MIN_ROWS} daily rows to train; got {n}.")
        dates = pd.DatetimeIndex(df["date"])
        self.last_date = dates[-1]
        for tgt in TARGETS:
            y = df[tgt].astype(float).to_numpy()
            if np.isnan(y).any():
                raise ValueError(f"Column '{tgt}' contains missing values.")
            errs, naive_errs, apes = [], [], []
            for o in (n - 21, n - 14, n - 7):                       # rolling-origin backtest
                X, T = _xy(y[:o], dates[:o])
                m = _new_model().fit(X, T)
                pred = _recursive(m, y[:o], dates[o - 1], 7)
                act = y[o:o + 7]
                errs += list(pred - act)
                naive_errs += list(y[o - 7:o] - act)                # seasonal naive (same weekday last week)
                apes += list(np.abs(pred - act) / np.maximum(act, 1e-6))
            mae, naive_mae = float(np.mean(np.abs(errs))), float(np.mean(np.abs(naive_errs)))
            self.sigma[tgt] = max(float(np.std(errs)), 0.5)
            self.metrics[tgt] = {
                "mae": round(mae, 2),
                "mape_pct": round(float(np.mean(apes)) * 100, 1),
                "naive_mae": round(naive_mae, 2),
                "improvement_vs_naive_pct": round((1 - mae / naive_mae) * 100, 1) if naive_mae > 0 else 0.0,
                "backtest_points": len(errs),
            }
            X, T = _xy(y, dates)
            self.models[tgt] = _new_model().fit(X, T)
            self.series[tgt] = y
        return self

    def predict(self, horizon: int = MAX_HORIZON) -> dict:
        """-> {target: {"values": arr, "lower": arr, "upper": arr}} (80 % band)."""
        out = {}
        for tgt in TARGETS:
            vals = _recursive(self.models[tgt], self.series[tgt], self.last_date, horizon)
            half = np.array([1.28 * self.sigma[tgt] * math.sqrt((k + 1) / 4.0) for k in range(horizon)])
            out[tgt] = {"values": vals, "lower": np.maximum(vals - half, 0.0), "upper": vals + half}
        return out
