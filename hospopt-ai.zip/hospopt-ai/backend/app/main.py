"""HospOpt AI - FastAPI application.   Run:  uvicorn app.main:app --reload --port 8000"""
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field
from starlette.concurrency import run_in_threadpool

from .models import Scenario
from .service import Engine

_engine: Optional[Engine] = None


def get_engine() -> Engine:
    global _engine
    if _engine is None:
        _engine = Engine()
    return _engine


@asynccontextmanager
async def lifespan(app: FastAPI):
    await run_in_threadpool(get_engine)      # train once at start-up
    yield


app = FastAPI(title="HospOpt AI", version="1.0.0", lifespan=lifespan,
              description="Predict -> Optimise -> Simulate -> Recommend for hospital resources.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ------------------------------------------------------------------ request models
class ScenarioIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    emergency_surge_pct: float = Field(0, ge=0, le=100)
    flu_season_pct: float = Field(0, ge=0, le=100)
    staff_absence_pct: float = Field(0, ge=0, le=50)
    beds_out_of_service: int = Field(0, ge=0, le=500)
    icu_beds_out_of_service: int = Field(0, ge=0, le=200)

    def core(self) -> Scenario:
        return Scenario(**self.model_dump())


class ResourcesPatch(BaseModel):
    """Partial update - send only the fields you want to change."""
    model_config = ConfigDict(extra="forbid")
    general_beds: Optional[int] = Field(None, ge=1, le=5000)
    icu_beds: Optional[int] = Field(None, ge=1, le=1000)
    doctors: Optional[int] = Field(None, ge=0, le=2000)
    nurses: Optional[int] = Field(None, ge=0, le=5000)
    operating_rooms: Optional[int] = Field(None, ge=1, le=100)
    er_capacity: Optional[int] = Field(None, ge=1, le=2000)
    or_hours_per_room: Optional[float] = Field(None, gt=0, le=24)
    emergency_reserve_pct: Optional[float] = Field(None, ge=0, le=0.5)
    nurse_ratio_icu: Optional[float] = Field(None, gt=0)
    nurse_ratio_ward: Optional[float] = Field(None, gt=0)
    nurse_er_per_nurse: Optional[float] = Field(None, gt=0)
    doctor_ratio_icu: Optional[float] = Field(None, gt=0)
    doctor_ratio_ward: Optional[float] = Field(None, gt=0)
    doctor_er_per_doctor: Optional[float] = Field(None, gt=0)
    stepdown_beds_free: Optional[int] = Field(None, ge=0)
    overflow_icu_pct: Optional[float] = Field(None, ge=0, le=1)
    regional_transfer_max: Optional[int] = Field(None, ge=0)
    nurse_callin_pool: Optional[int] = Field(None, ge=0)
    doctor_callin_pool: Optional[int] = Field(None, ge=0)
    elective_share: Optional[float] = Field(None, ge=0, le=1)
    or_elective_share: Optional[float] = Field(None, ge=0, le=1)
    avg_surgery_hours: Optional[float] = Field(None, gt=0)

    def patch(self) -> dict:
        return self.model_dump(exclude_none=True)


class PlanRequest(BaseModel):
    horizon: int = Field(7, ge=1, le=7, description="Forecast days: 1, 3 or 7 (any 1-7 works)")
    scenario: ScenarioIn = Field(default_factory=ScenarioIn)
    resources: Optional[ResourcesPatch] = Field(None, description="Temporary what-if overrides (not saved)")


def _guard(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))


# ------------------------------------------------------------------ endpoints
@app.get("/api/health", tags=["system"])
def health():
    return get_engine().health()


@app.get("/api/overview", tags=["dashboard"])
def overview():
    return get_engine().overview()


@app.get("/api/history", tags=["dashboard"])
def history(days: int = Query(14, ge=7, le=120)):
    return get_engine().history(days)


@app.get("/api/resources", tags=["resources"])
def get_resources():
    return get_engine().resources.to_dict()


@app.put("/api/resources", tags=["resources"])
def put_resources(patch: ResourcesPatch):
    return _guard(get_engine().update_resources, patch.patch())


@app.post("/api/forecast", tags=["ai"])
def forecast(req: PlanRequest):
    return _guard(get_engine().forecast, req.horizon, req.scenario.core())


@app.post("/api/optimize", tags=["ai"])
def optimize(req: PlanRequest):
    patch = req.resources.patch() if req.resources else None
    return _guard(get_engine().optimize, req.horizon, req.scenario.core(), patch)


@app.post("/api/simulate", tags=["ai"])
def simulate(req: PlanRequest):
    patch = req.resources.patch() if req.resources else None
    return _guard(get_engine().simulate, req.horizon, req.scenario.core(), patch)


@app.get("/api/model/metrics", tags=["model"])
def model_metrics():
    return get_engine().model_info()


@app.post("/api/model/retrain", tags=["model"])
def model_retrain():
    return _guard(get_engine().retrain)


@app.post("/api/data/upload", tags=["data"])
async def data_upload(file: UploadFile = File(...)):
    content = await file.read()
    return await run_in_threadpool(_guard, get_engine().upload_csv, content)


@app.post("/api/data/reset", tags=["data"])
def data_reset():
    return _guard(get_engine().reset_synthetic)


@app.get("/api/data/export", tags=["data"])
def data_export(days: int = Query(90, ge=60, le=365)):
    return Response(get_engine().export_csv(days), media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=hospital_data.csv"})


# Serve the built React app (frontend/dist) from the same origin if it exists.
_dist = Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"
if _dist.exists():
    app.mount("/", StaticFiles(directory=str(_dist), html=True), name="ui")
