"""Resource optimisation: one small integer linear program per forecast day.

Decision variables (all >= 0, integers unless noted)
  overflow       extra ICU beds opened                 stepdown   ICU -> step-down transfers
  transfer       regional ICU transfers                defer_adm  elective admissions deferred
  defer_surg     non-urgent surgeries rescheduled      nurse_callin / doctor_callin  extra staff
  un_*           (continuous) unmet demand slack - hugely penalised, keeps the model always feasible
                 and tells the administrator exactly what cannot be covered ("escalate").

Constraints: ICU patients <= ICU beds + overflow, ward patients (incl. step-down arrivals) <= beds minus
emergency reserve, OR hours <= hours minus emergency reserve, nurses / doctors needed <= on duty + call-ins.
Staffing couples the beds: moving a patient ICU -> ward frees nurse time (1:1.5 vs 1:5) - the solver
weighs that against ward capacity automatically.

Solver: PuLP/CBC when available, transparent fallback to SciPy HiGHS (same model, same answer).
"""
import math
from dataclasses import dataclass
import numpy as np
from .config import COSTS, HIGH_UTIL, CRITICAL_UTIL, LABELS
from .models import Resources

_TOL = 1e-6


@dataclass
class _Var:
    name: str
    ub: float | None
    cost: float
    integer: bool = True


@dataclass
class _Con:
    label: str
    coeffs: dict
    rhs: float          # constraint is  sum(coeffs * vars) <= rhs


def status_of(util: float) -> str:
    return "CRITICAL" if util >= CRITICAL_UTIL else "HIGH" if util >= HIGH_UTIL else "OK"


def staff_need(icu: float, ward: float, er: float, r: Resources) -> tuple:
    nurses = icu / r.nurse_ratio_icu + ward / r.nurse_ratio_ward + er / r.nurse_er_per_nurse
    doctors = icu / r.doctor_ratio_icu + ward / r.doctor_ratio_ward + er / r.doctor_er_per_doctor
    return nurses, doctors


def reserve_beds(r: Resources) -> int:
    return math.ceil(r.emergency_reserve_pct * r.general_beds - 1e-9)


# ----------------------------------------------------------------------------- model
def build_model(d: dict, r: Resources):
    icu_d, ward_d, er_d, or_d = d["icu"], d["beds"], d["er"], d["or"]
    ward_cap = r.general_beds - reserve_beds(r)
    or_cap = r.or_hours * (1 - r.emergency_reserve_pct)
    ri, rw, re_ = r.nurse_ratio_icu, r.nurse_ratio_ward, r.nurse_er_per_nurse
    di, dw, de = r.doctor_ratio_icu, r.doctor_ratio_ward, r.doctor_er_per_doctor

    V = lambda n, ub, integer=True: _Var(n, ub, COSTS[n], integer)
    variables = [
        V("overflow", math.floor(r.overflow_icu_pct * r.icu_beds)),
        V("stepdown", min(r.stepdown_beds_free, math.floor(0.2 * icu_d))),
        V("transfer", min(r.regional_transfer_max, math.floor(icu_d))),
        V("defer_adm", math.floor(r.elective_share * ward_d)),
        V("defer_surg", math.floor(r.or_elective_share * or_d / r.avg_surgery_hours)),
        V("nurse_callin", r.nurse_callin_pool),
        V("doctor_callin", r.doctor_callin_pool),
        V("un_icu", None, False), V("un_ward", None, False), V("un_or", None, False),
        V("un_nurse", None, False), V("un_doc", None, False),
    ]
    n_need0, d_need0 = staff_need(icu_d, ward_d, er_d, r)
    cons = [
        _Con("icu", {"stepdown": -1, "transfer": -1, "overflow": -1, "un_icu": -1}, r.icu_beds - icu_d),
        _Con("ward", {"stepdown": 1, "defer_adm": -1, "un_ward": -1}, ward_cap - ward_d),
        _Con("or", {"defer_surg": -r.avg_surgery_hours, "un_or": -1}, or_cap - or_d),
        _Con("nurses", {"stepdown": -1 / ri + 1 / rw, "transfer": -1 / ri, "un_icu": -1 / ri,
                        "defer_adm": -1 / rw, "un_ward": -1 / rw, "nurse_callin": -1, "un_nurse": -1},
             r.nurses - n_need0),
        _Con("doctors", {"stepdown": -1 / di + 1 / dw, "transfer": -1 / di, "un_icu": -1 / di,
                         "defer_adm": -1 / dw, "un_ward": -1 / dw, "doctor_callin": -1, "un_doc": -1},
             r.doctors - d_need0),
    ]
    return variables, cons


# ----------------------------------------------------------------------------- solvers
def _solve_pulp(variables, cons):
    import pulp
    prob = pulp.LpProblem("hospopt", pulp.LpMinimize)
    x = {v.name: pulp.LpVariable(v.name, lowBound=0, upBound=v.ub,
                                 cat="Integer" if v.integer else "Continuous") for v in variables}
    prob += pulp.lpSum(v.cost * x[v.name] for v in variables)
    for i, c in enumerate(cons):
        prob += (pulp.lpSum(k * x[n] for n, k in c.coeffs.items()) <= c.rhs, f"c{i}")
    prob.solve(pulp.PULP_CBC_CMD(msg=False))
    if pulp.LpStatus[prob.status] != "Optimal":
        raise RuntimeError(f"PuLP status: {pulp.LpStatus[prob.status]}")
    return {n: float(v.value() or 0.0) for n, v in x.items()}, float(pulp.value(prob.objective)), "pulp-cbc"


def _solve_scipy(variables, cons):
    from scipy.optimize import milp, LinearConstraint, Bounds
    idx = {v.name: i for i, v in enumerate(variables)}
    A = np.zeros((len(cons), len(variables)))
    for i, c in enumerate(cons):
        for n, k in c.coeffs.items():
            A[i, idx[n]] = k
    res = milp(
        c=np.array([v.cost for v in variables]),
        constraints=LinearConstraint(A, -np.inf, np.array([c.rhs for c in cons])),
        integrality=np.array([1 if v.integer else 0 for v in variables]),
        bounds=Bounds(np.zeros(len(variables)), np.array([np.inf if v.ub is None else v.ub for v in variables])),
    )
    if not res.success:
        raise RuntimeError(f"HiGHS: {res.message}")
    return {v.name: float(res.x[i]) for i, v in enumerate(variables)}, float(res.fun), "scipy-highs"


def available_solver() -> str:
    try:
        import pulp  # noqa: F401
        return "pulp-cbc"
    except Exception:
        return "scipy-highs"


def solve(variables, cons):
    try:
        sol, obj, name = _solve_pulp(variables, cons)
    except Exception:
        sol, obj, name = _solve_scipy(variables, cons)
    clean = {}
    for v in variables:
        val = sol.get(v.name, 0.0)
        clean[v.name] = int(round(val)) if v.integer else (0.0 if val < _TOL else float(val))
    return clean, obj, name


# ----------------------------------------------------------------------------- plan for one day
def plan_day(day: int, date: str, weekday: str, d: dict, r: Resources) -> dict:
    icu_d, ward_d, er_d, or_d = d["icu"], d["beds"], d["er"], d["or"]
    variables, cons = build_model(d, r)
    s, objective, solver = solve(variables, cons)

    reserve, ward_cap = reserve_beds(r), r.general_beds - reserve_beds(r)
    or_cap = r.or_hours * (1 - r.emergency_reserve_pct)
    n0, d0 = staff_need(icu_d, ward_d, er_d, r)
    util = {
        "beds": ward_d / r.general_beds, "icu": icu_d / r.icu_beds, "er": er_d / r.er_capacity,
        "or": or_d / r.or_hours, "nurses": n0 / max(r.nurses, 1e-9), "doctors": d0 / max(r.doctors, 1e-9),
    }
    risk = max(util.values())

    icu_srv = icu_d - s["stepdown"] - s["transfer"] - s["un_icu"]
    ward_srv = ward_d + s["stepdown"] - s["defer_adm"] - s["un_ward"]
    or_srv = or_d - r.avg_surgery_hours * s["defer_surg"] - s["un_or"]
    n1, d1 = staff_need(icu_srv, ward_srv, er_d, r)

    # ---- human-readable actions with the reason behind each --------------------------------
    A = []
    def act(kind, qty, text, why, priority):
        A.append({"type": kind, "quantity": qty, "text": text, "reason": why, "priority": priority})
    if s["stepdown"]:
        act("stepdown", s["stepdown"], f"Move {s['stepdown']} eligible ICU patient(s) to step-down care",
            f"ICU demand {icu_d:.1f} exceeds {r.icu_beds} beds; step-down is the lowest-risk, lowest-cost lever "
            f"and frees ICU nursing time (1:{r.nurse_ratio_icu:g} -> 1:{r.nurse_ratio_ward:g}).", 1)
    if s["overflow"]:
        act("overflow", s["overflow"], f"Open {s['overflow']} overflow ICU bed(s)",
            f"Remaining ICU gap after step-down; overflow beds cost less than transfers "
            f"(limit {math.floor(r.overflow_icu_pct * r.icu_beds)}).", 1)
    if s["transfer"]:
        act("transfer", s["transfer"], f"Arrange {s['transfer']} regional ICU transfer(s)",
            "Local ICU capacity (incl. overflow) exhausted.", 1)
    if s["defer_adm"]:
        act("defer_adm", s["defer_adm"], f"Defer {s['defer_adm']} elective admission(s) / pull forward discharges",
            f"Ward demand {ward_srv + s['defer_adm']:.1f} would breach the {reserve}-bed emergency reserve "
            f"(usable beds {ward_cap}).", 2)
    if s["defer_surg"]:
        act("defer_surg", s["defer_surg"],
            f"Reschedule {s['defer_surg']} non-urgent surgeries (~{s['defer_surg'] * r.avg_surgery_hours:.0f} OR hours)",
            f"OR demand {or_d:.1f}h exceeds {or_cap:.0f}h usable after the {r.emergency_reserve_pct:.0%} emergency reserve.", 2)
    if s["nurse_callin"]:
        act("nurse_callin", s["nurse_callin"], f"Call in / reassign {s['nurse_callin']} nurse(s)",
            f"Nurses required {n0:.1f} vs {r.nurses} on duty.", 2)
    if s["doctor_callin"]:
        act("doctor_callin", s["doctor_callin"], f"Add {s['doctor_callin']} doctor(s) to the roster",
            f"Doctors required {d0:.1f} vs {r.doctors} on duty.", 2)
    esc = [("un_icu", "ICU patient(s) cannot be accommodated", "icu"),
           ("un_ward", "ward patient(s) cannot be accommodated", "beds"),
           ("un_or", "OR hours cannot be covered", "or"),
           ("un_nurse", "nurse(s) short even after call-ins", "nurses"),
           ("un_doc", "doctor(s) short even after call-ins", "doctors")]
    for key, msg, _ in esc:
        if s[key] > 0.05:
            act("escalate", round(s[key], 1), f"ESCALATE: {s[key]:.1f} {msg} - activate hospital surge protocol",
                "All configured levers are exhausted for this day.", 0)
    tight = [f"{LABELS[k]} {u:.0%}" for k, u in util.items() if HIGH_UTIL <= u < 1.0]
    if tight:
        act("monitor", 0, "Monitor closely: " + ", ".join(tight),
            "Demand fits within capacity but headroom is thin - no corrective lever needed yet.", 3)
    act("reserve", reserve, f"Keep {reserve} general beds free as emergency reserve ({r.emergency_reserve_pct:.0%})",
        "Policy constraint - never allocated to scheduled demand.", 4)
    if len(A) == 1:
        act("none", 0, "No intervention required - resources are sufficient", "Every resource is below the HIGH utilisation threshold.", 5)
    A.sort(key=lambda a: a["priority"])

    # ---- constraint verification (post-allocation) ------------------------------------------
    def con(name, lhs, rhs, unit):
        ok = lhs <= rhs + 1e-6
        return {"name": name, "lhs": round(lhs, 1), "rhs": round(rhs, 1), "unit": unit, "ok": ok,
                "binding": ok and rhs > 0 and lhs >= 0.98 * rhs}
    C = [
        con("ICU patients <= ICU beds + overflow", icu_srv, r.icu_beds + s["overflow"], "beds"),
        con("Ward patients <= beds - emergency reserve", ward_srv, ward_cap, "beds"),
        con(f"Free beds >= {r.emergency_reserve_pct:.0%} emergency reserve", reserve, r.general_beds - ward_srv, "beds"),
        con("OR hours used <= usable OR hours", or_srv, or_cap, "hours"),
        con("Nurses needed <= on duty + call-ins", n1, r.nurses + s["nurse_callin"], "nurses"),
        con("Doctors needed <= on duty + call-ins", d1, r.doctors + s["doctor_callin"], "doctors"),
    ]
    # reserve row is expressed "reserve <= free beds"
    base = {
        "icu_without_bed": max(0.0, icu_d - r.icu_beds),
        "reserve_breach_beds": max(0.0, ward_d - ward_cap),
        "or_hours_over": max(0.0, or_d - or_cap),
        "nurse_gap": max(0.0, n0 - r.nurses),
        "doctor_gap": max(0.0, d0 - r.doctors),
    }
    after = {"icu_without_bed": s["un_icu"], "reserve_breach_beds": s["un_ward"], "or_hours_over": s["un_or"],
             "nurse_gap": s["un_nurse"], "doctor_gap": s["un_doc"]}
    return {
        "day": day, "date": date, "weekday": weekday,
        "demand": {k: round(float(v), 1) for k, v in d.items()},
        "utilization": {k: round(float(v), 3) for k, v in util.items()},
        "staff_required": {"nurses": round(n0, 1), "doctors": round(d0, 1)},
        "status": status_of(risk), "risk": round(float(risk), 3),
        "levers": {k: s[k] for k in ("stepdown", "overflow", "transfer", "defer_adm", "defer_surg", "nurse_callin", "doctor_callin")},
        "actions": A, "constraints": C,
        "baseline_gap": {k: round(v, 1) for k, v in base.items()},
        "after_gap": {k: round(float(v), 1) for k, v in after.items()},
        "objective": round(objective, 1), "solver": solver,
    }
