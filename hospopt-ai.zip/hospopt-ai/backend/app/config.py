"""Central configuration: forecast targets, thresholds, optimisation costs, scenario coupling."""

# Time series the ML layer forecasts (daily). Keys are column names in the dataset.
TARGETS = ["beds_occupied", "icu_occupied", "emergency_cases", "or_hours_used"]

# Short keys used by the optimiser / API for the same four series.
KEY_OF = {
    "beds_occupied": "beds",
    "icu_occupied": "icu",
    "emergency_cases": "er",
    "or_hours_used": "or",
}

LABELS = {
    "beds": "General beds",
    "icu": "ICU",
    "er": "Emergency department",
    "or": "Operating rooms",
    "nurses": "Nurses",
    "doctors": "Doctors",
}

MAX_HORIZON = 7        # days
MIN_ROWS = 60          # minimum history needed to train + backtest
HIGH_UTIL = 0.85       # >= HIGH
CRITICAL_UTIL = 0.95   # >= CRITICAL

# Columns of the stored dataset. First five are required for CSV uploads.
REQUIRED_COLUMNS = ["date", "beds_occupied", "icu_occupied", "emergency_cases", "or_hours_used"]
STANDARD_COLUMNS = [
    "date", "admissions", "emergency_cases", "icu_admissions", "icu_occupied",
    "beds_occupied", "avg_stay", "doctors_available", "nurses_available",
    "or_hours_used", "scheduled_surgeries", "beds_total", "icu_total",
]

# Objective weights for the integer program (lower = preferred action).
# Ordering encodes clinical preference: step-down < overflow < defer < transfer.
COSTS = {
    "stepdown": 2.0,
    "overflow": 3.0,
    "nurse_callin": 4.0,
    "defer_adm": 5.0,
    "defer_surg": 6.0,
    "doctor_callin": 7.0,
    "transfer": 8.0,
    # Penalties for demand that cannot be met -> only used when every lever is exhausted.
    "un_icu": 2000.0,
    "un_ward": 1000.0,
    "un_or": 800.0,
    "un_nurse": 600.0,
    "un_doc": 800.0,
}

# What-if coupling: how much a 1% emergency surge moves other demand streams.
# (Assumptions - editable; documented in the README.)
SURGE_COUPLING = {"er": 1.0, "icu": 0.5, "beds": 0.25, "or": 0.3}
# Flu-season coupling: 1% flu-season pressure.
FLU_COUPLING = {"er": 0.3, "icu": 0.4, "beds": 1.0, "or": 0.0}
