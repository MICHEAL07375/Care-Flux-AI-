"""Plain dataclasses shared by every layer (no web-framework dependency -> easy to unit test)."""
from dataclasses import dataclass, asdict, fields, replace


@dataclass(frozen=True)
class Resources:
    # --- capacity -------------------------------------------------------------
    general_beds: int = 150
    icu_beds: int = 30
    doctors: int = 25
    nurses: int = 52
    operating_rooms: int = 5
    er_capacity: int = 65                 # ER visits / day the department can absorb
    or_hours_per_room: float = 10.0
    # --- policy ---------------------------------------------------------------
    emergency_reserve_pct: float = 0.10   # share of beds / OR hours kept free for emergencies
    # --- staffing ratios (patients per staff member) --------------------------
    nurse_ratio_icu: float = 1.5
    nurse_ratio_ward: float = 5.0
    nurse_er_per_nurse: float = 8.0       # ER visits / day per nurse
    doctor_ratio_icu: float = 4.0
    doctor_ratio_ward: float = 12.0
    doctor_er_per_doctor: float = 10.0
    # --- levers available to the optimiser ------------------------------------
    stepdown_beds_free: int = 6
    overflow_icu_pct: float = 0.20        # overflow ICU beds as a share of ICU beds
    regional_transfer_max: int = 4
    nurse_callin_pool: int = 8
    doctor_callin_pool: int = 3
    elective_share: float = 0.12          # share of ward demand that is deferrable
    or_elective_share: float = 0.35       # share of OR hours that is deferrable
    avg_surgery_hours: float = 2.0

    @property
    def or_hours(self) -> float:
        return self.operating_rooms * self.or_hours_per_room

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Resources":
        known = {f.name: f for f in fields(cls)}
        clean = {}
        for k, v in data.items():
            if k not in known:
                raise ValueError(f"Unknown resource field: {k}")
            clean[k] = known[k].type(v)
        res = cls(**clean)
        res.validate()
        return res

    def validate(self) -> None:
        for name in ("general_beds", "icu_beds", "operating_rooms", "er_capacity"):
            if getattr(self, name) < 1:
                raise ValueError(f"{name} must be >= 1")
        for name in ("doctors", "nurses", "stepdown_beds_free", "regional_transfer_max",
                     "nurse_callin_pool", "doctor_callin_pool"):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} must be >= 0")
        for name in ("or_hours_per_room", "nurse_ratio_icu", "nurse_ratio_ward", "nurse_er_per_nurse",
                     "doctor_ratio_icu", "doctor_ratio_ward", "doctor_er_per_doctor", "avg_surgery_hours"):
            if getattr(self, name) <= 0:
                raise ValueError(f"{name} must be > 0")
        for name in ("emergency_reserve_pct", "overflow_icu_pct", "elective_share", "or_elective_share"):
            if not 0 <= getattr(self, name) <= 1:
                raise ValueError(f"{name} must be between 0 and 1")


@dataclass(frozen=True)
class Scenario:
    emergency_surge_pct: float = 0.0   # e.g. 20 -> +20 % emergency admissions
    flu_season_pct: float = 0.0        # general respiratory-season pressure
    staff_absence_pct: float = 0.0     # share of nurses/doctors unavailable
    beds_out_of_service: int = 0
    icu_beds_out_of_service: int = 0

    @property
    def is_baseline(self) -> bool:
        return all(v == 0 for v in asdict(self).values())

    def to_dict(self) -> dict:
        return asdict(self)


def adjust_resources(res: Resources, sc: Scenario) -> Resources:
    """Apply capacity-side scenario effects (staff absence, closed beds)."""
    keep = 1.0 - sc.staff_absence_pct / 100.0
    return replace(
        res,
        nurses=max(0, int(round(res.nurses * keep))),
        doctors=max(0, int(round(res.doctors * keep))),
        general_beds=max(1, res.general_beds - sc.beds_out_of_service),
        icu_beds=max(1, res.icu_beds - sc.icu_beds_out_of_service),
    )
