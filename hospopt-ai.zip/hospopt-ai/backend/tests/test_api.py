"""HTTP-level tests. Skipped automatically if FastAPI isn't installed."""
import os, tempfile
os.environ["HOSPOPT_DB"] = tempfile.mktemp(suffix=".db")
import pytest
pytest.importorskip("fastapi")
pytest.importorskip("httpx")
from fastapi.testclient import TestClient
from app.main import app
from app.models import Resources


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def test_health_and_overview(client):
    assert client.get("/api/health").json()["status"] == "ok"
    kpis = client.get("/api/overview").json()["kpis"]
    assert {k["key"] for k in kpis} == {"beds", "icu", "er", "or", "nurses", "doctors"}


def test_patch_model_covers_every_resource_field(client):
    from app.main import ResourcesPatch
    assert set(ResourcesPatch.model_fields) == set(Resources().to_dict())


def test_optimize_and_simulate(client):
    r = client.post("/api/optimize", json={"horizon": 3}).json()
    assert len(r["plans"]) == 3 and r["summary"]
    s = client.post("/api/simulate", json={"horizon": 7, "scenario": {"emergency_surge_pct": 20}}).json()
    assert s["scenario"]["scenario"]["emergency_surge_pct"] == 20
    assert max(s["scenario"]["forecast"]["utilization"]["er"]) > max(s["baseline"]["forecast"]["utilization"]["er"])


def test_validation_errors(client):
    assert client.post("/api/optimize", json={"horizon": 99}).status_code == 422
    assert client.post("/api/optimize", json={"scenario": {"emergency_surge_pct": -5}}).status_code == 422
    assert client.put("/api/resources", json={"icu_beds": 0}).status_code == 422
    assert client.put("/api/resources", json={"nope": 1}).status_code == 422


def test_resources_roundtrip_and_override(client):
    assert client.put("/api/resources", json={"nurses": 70}).json()["nurses"] == 70
    r = client.post("/api/optimize", json={"horizon": 1, "resources": {"nurses": 40}}).json()
    assert r["resources"]["nurses"] == 40
    assert client.get("/api/resources").json()["nurses"] == 70       # override was not persisted


def test_upload_export_reset(client):
    csv = client.get("/api/data/export?days=90").text
    ok = client.post("/api/data/upload", files={"file": ("d.csv", csv, "text/csv")})
    assert ok.status_code == 200 and ok.json()["data_source"] == "upload"
    bad = client.post("/api/data/upload", files={"file": ("d.csv", "a,b\n1,2\n", "text/csv")})
    assert bad.status_code == 422
    assert client.post("/api/data/reset").json()["data_source"] == "synthetic"
