"""Core tests (no web framework needed).  Run:  pytest -q"""
import os, tempfile
os.environ["HOSPOPT_DB"] = tempfile.mktemp(suffix=".db")

import numpy as np
import pandas as pd
from app.data_gen import generate_synthetic
from app.forecast import DemandForecaster
from app.models import Resources, Scenario, adjust_resources
from app.optimizer import plan_day, build_model, _solve_scipy, solve
from app.service import Engine, parse_csv, scenario_multipliers

R = Resources()
DEMANDS = [
    dict(icu=20, beds=100, er=40, **{"or": 30}),
    dict(icu=29, beds=135, er=55, **{"or": 46}),
    dict(icu=33, beds=148, er=70, **{"or": 55}),
    dict(icu=45, beds=170, er=90, **{"or": 70}),   # beyond every lever -> must escalate, not crash
]


def test_synthetic_data_shape():
    df = generate_synthetic(end_date="2026-10-04")
    assert len(df) == 180 and df["date"].is_monotonic_increasing
    assert df["beds_occupied"].max() <= 148 and df["icu_occupied"].max() <= 30
    assert not df[["beds_occupied", "icu_occupied", "emergency_cases", "or_hours_used"]].isna().any().any()


def test_forecast_beats_naive_and_is_sane():
    df = generate_synthetic(end_date="2026-10-04")
    f = DemandForecaster().fit(df)
    for tgt, m in f.metrics.items():
        assert m["mae"] <= m["naive_mae"] * 1.1, (tgt, m)    # not meaningfully worse than naive
    p = f.predict(7)
    for tgt in p:
        v = p[tgt]
        assert len(v["values"]) == 7 and (v["lower"] <= v["values"]).all() and (v["values"] <= v["upper"]).all()
        assert (v["values"] >= 0).all()


def test_optimizer_respects_constraints_whenever_no_escalation():
    for d in DEMANDS:
        p = plan_day(1, "2026-10-05", "Mon", d, R)
        escalated = any(a["type"] == "escalate" for a in p["actions"])
        if not escalated:
            assert all(c["ok"] for c in p["constraints"]), (d, p["constraints"])
            assert sum(p["after_gap"].values()) == 0
        # levers never exceed their configured limits
        lv = p["levers"]
        assert lv["overflow"] <= int(R.overflow_icu_pct * R.icu_beds)
        assert lv["transfer"] <= R.regional_transfer_max and lv["nurse_callin"] <= R.nurse_callin_pool


def test_no_action_when_demand_is_low():
    p = plan_day(1, "2026-10-05", "Mon", DEMANDS[0], R)
    assert sum(p["levers"].values()) == 0 and p["status"] == "OK"


def test_overflow_used_when_icu_exceeds_capacity():
    p = plan_day(1, "2026-10-05", "Mon", dict(icu=32, beds=100, er=40, **{"or": 30}), R)
    assert p["levers"]["stepdown"] + p["levers"]["overflow"] + p["levers"]["transfer"] >= 2
    assert p["after_gap"]["icu_without_bed"] == 0


def test_scipy_and_default_solver_agree():
    for d in DEMANDS[:3]:
        v, c = build_model(d, R)
        a = _solve_scipy(v, c)[1]
        b = solve(v, c)[1]
        assert abs(a - b) < 1e-4


def test_scenario_multipliers_and_resources():
    m = scenario_multipliers(Scenario(emergency_surge_pct=20))
    assert abs(m["er"] - 1.2) < 1e-9 and abs(m["icu"] - 1.1) < 1e-9
    r2 = adjust_resources(R, Scenario(staff_absence_pct=10, beds_out_of_service=5))
    assert r2.nurses < R.nurses and r2.general_beds == R.general_beds - 5


def test_engine_end_to_end():
    e = Engine()
    base = e.optimize(7, Scenario())
    surge = e.optimize(7, Scenario(emergency_surge_pct=30))
    assert len(base["plans"]) == 7
    for k in ("icu", "beds", "er", "or"):
        assert max(surge["forecast"]["utilization"][k]) > max(base["forecast"]["utilization"][k])
    sim = e.simulate(3, Scenario(emergency_surge_pct=20))
    assert len(sim["comparison"]) == 6 and len(sim["scenario"]["plans"]) == 3
    assert e.simulate(3, Scenario())["scenario"]["scenario"]["emergency_surge_pct"] == 0
    e.update_resources({"icu_beds": 28})
    assert e.overview()["resources"]["icu_beds"] == 28
    try:
        e.update_resources({"icu_beds": 0}); assert False
    except ValueError:
        pass
    try:
        e.optimize(9, Scenario()); assert False
    except ValueError:
        pass


def test_csv_roundtrip_and_validation():
    e = Engine()
    csv = e.export_csv(90)
    assert e.upload_csv(csv.encode())["data_source"] == "upload"
    for bad, msg in [(b"date,foo\n2026-01-01,1\n", "missing required"), (b"not,a,csv\x00\xff", None)]:
        try:
            parse_csv(bad); assert False
        except ValueError as err:
            if msg: assert msg in str(err)
    short = "date,beds_occupied,icu_occupied,emergency_cases,or_hours_used\n" + "\n".join(
        f"2026-01-{d:02d},100,20,40,30" for d in range(1, 11))
    try:
        parse_csv(short.encode()); assert False
    except ValueError as err:
        assert "at least" in str(err)
    assert e.reset_synthetic()["data_source"] == "synthetic"


def test_every_response_is_json_serialisable():
    import json
    e = Engine()
    json.dumps(e.simulate(7, Scenario(emergency_surge_pct=40, staff_absence_pct=10)))
    json.dumps([e.overview(), e.history(14), e.model_info(), e.health(), e.forecast(3, Scenario())])
