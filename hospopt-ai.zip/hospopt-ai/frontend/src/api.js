export const BASE = import.meta.env.VITE_API_URL || "";

async function req(path, opts = {}) {
  const isForm = opts.body instanceof FormData;
  const res = await fetch(BASE + path, {
    ...opts,
    headers: isForm ? {} : { "Content-Type": "application/json" },
  });
  if (!res.ok) {
    let msg = `${res.status} ${res.statusText}`;
    try {
      const j = await res.json();
      msg = typeof j.detail === "string" ? j.detail : JSON.stringify(j.detail);
    } catch (_) { /* keep default */ }
    throw new Error(msg);
  }
  return res.json();
}

export const api = {
  health: () => req("/api/health"),
  overview: () => req("/api/overview"),
  history: (days = 14) => req(`/api/history?days=${days}`),
  metrics: () => req("/api/model/metrics"),
  saveResources: (patch) => req("/api/resources", { method: "PUT", body: JSON.stringify(patch) }),
  simulate: (body) => req("/api/simulate", { method: "POST", body: JSON.stringify(body) }),
  retrain: () => req("/api/model/retrain", { method: "POST" }),
  reset: () => req("/api/data/reset", { method: "POST" }),
  upload: (file) => {
    const f = new FormData();
    f.append("file", file);
    return req("/api/data/upload", { method: "POST", body: f });
  },
};
