import { useCallback, useEffect, useRef, useState } from "react";
import { Activity, AlertTriangle } from "lucide-react";
import { api } from "./api";
import { DEFAULT_SCENARIO } from "./constants.js";
import Controls from "./components/Controls.jsx";
import Kpis from "./components/Kpis.jsx";
import ForecastChart from "./components/ForecastChart.jsx";
import Heatmap from "./components/Heatmap.jsx";
import Plan from "./components/Plan.jsx";
import Simulator from "./components/Simulator.jsx";

const ICON = { CRITICAL: "🔴", HIGH: "🟠" };

export default function App() {
  const [health, setHealth] = useState(null);
  const [overview, setOverview] = useState(null);
  const [history, setHistory] = useState(null);
  const [model, setModel] = useState(null);
  const [horizon, setHorizon] = useState(7);
  const [scenario, setScenario] = useState(DEFAULT_SCENARIO);
  const [sim, setSim] = useState(null);
  const [day, setDay] = useState(null);
  const [metric, setMetric] = useState("icu");
  const [version, setVersion] = useState(0);
  const [err, setErr] = useState(null);
  const [loading, setLoading] = useState(false);
  const reqId = useRef(0);

  const fail = useCallback((e) => setErr(e?.message || String(e)), []);

  // static data: reload whenever resources or the dataset change
  useEffect(() => {
    Promise.all([api.health(), api.overview(), api.history(14), api.metrics()])
      .then(([h, o, hi, m]) => { setHealth(h); setOverview(o); setHistory(hi); setModel(m); setErr(null); })
      .catch((e) => fail(new Error(`Cannot reach the backend (${e.message}). Start it with: uvicorn app.main:app --port 8000`)));
  }, [version, fail]);

  // simulation: debounced; stale responses are ignored
  useEffect(() => {
    const id = ++reqId.current;
    setLoading(true);
    const t = setTimeout(() => {
      api.simulate({ horizon, scenario })
        .then((r) => { if (id === reqId.current) { setSim(r); setDay(null); setErr(null); } })
        .catch((e) => { if (id === reqId.current) fail(e); })
        .finally(() => { if (id === reqId.current) setLoading(false); });
    }, 250);
    return () => clearTimeout(t);
  }, [horizon, scenario, version, fail]);

  const result = sim?.scenario;
  const refresh = () => setVersion((v) => v + 1);

  return (
    <div className="app">
      <div className="top">
        <div>
          <h1>🏥 HospOpt AI</h1>
          <div className="sub">Hospital Resource Intelligence Platform · Predict → Optimize → Simulate → Recommend</div>
        </div>
        {health && (
          <div className="badges">
            <span className="badge">Model: {health.forecast_engine}</span>
            <span className="badge">Optimizer: {health.solver}</span>
            <span className="badge">Data: {health.data_source} · {health.data_rows} days · to {health.last_date}</span>
          </div>
        )}
      </div>

      {err && <div className="err">⚠️ {err}</div>}

      <div className="layout">
        <Controls
          resources={overview?.resources} horizon={horizon} setHorizon={setHorizon}
          scenario={scenario} setScenario={setScenario} onChanged={refresh} onError={fail}
        />
        <div className={`col ${loading ? "loading" : ""}`}>
          {overview && <Kpis kpis={overview.kpis} asOf={overview.as_of} />}

          {result && (
            <>
              <div className="two">
                <div className="card">
                  <h2><AlertTriangle size={13} /> AI alerts</h2>
                  {result.alerts.length === 0 && <div className="ok">No shortages predicted in this window.</div>}
                  <ul className="clean">
                    {result.alerts.map((a) => (
                      <li key={a.resource} className="alert"><span>{ICON[a.severity]}</span><span>{a.message}</span></li>
                    ))}
                  </ul>
                </div>
                <div className="card">
                  <h2><Activity size={13} /> Decision summary</h2>
                  <div className="summary">{result.summary}</div>
                  <div className="small mu">
                    Without action: <b>{result.impact.shortfall_before}</b> units of shortfall across the window ·
                    with optimized plan: <b className={result.impact.shortfall_after > 0 ? "bad" : "ok"}>{result.impact.shortfall_after}</b>
                    {" "}· {result.impact.interventions} interventions · {result.impact.days_critical} critical day(s)
                  </div>
                </div>
              </div>

              <ForecastChart history={history} sim={sim} metric={metric} setMetric={setMetric} model={model} />
              <Heatmap result={result} />
              <Plan result={result} selected={day} setSelected={setDay} />
              <Simulator sim={sim} />
            </>
          )}
          {!result && !err && <div className="card">Running forecast and optimization…</div>}
        </div>
      </div>
    </div>
  );
}
