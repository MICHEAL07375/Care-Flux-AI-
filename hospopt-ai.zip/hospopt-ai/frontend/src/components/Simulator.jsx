export default function Simulator({ sim }) {
  const active = Object.values(sim.scenario.scenario).some((v) => v !== 0);
  return (
    <div className="card">
      <h2>🔥 What-if simulator · peak utilisation in window</h2>
      {!active && <div className="small mu" style={{ marginBottom: 6 }}>Move a scenario slider (or press “Emergency +20%”) to compare against baseline.</div>}
      <div className="tw">
        <table>
          <thead><tr><th>Resource</th><th>Baseline</th><th>Scenario</th><th>Change</th><th>Status</th></tr></thead>
          <tbody>
            {sim.comparison.map((r) => (
              <tr key={r.key}>
                <td>{r.label}</td>
                <td>{Math.round(r.baseline_peak_util * 100)}% <span className={`pill ${r.baseline_status}`}>{r.baseline_status}</span></td>
                <td><b>{Math.round(r.scenario_peak_util * 100)}%</b></td>
                <td className={r.delta_pts > 0 ? "bad" : ""}>{r.delta_pts > 0 ? "+" : ""}{r.delta_pts} pts</td>
                <td><span className={`pill ${r.scenario_status}`}>{r.scenario_status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {active && (
        <div className="small mu" style={{ marginTop: 8 }}>
          Scenario multipliers on forecast demand: {Object.entries(sim.scenario.forecast.multipliers).map(([k, v]) => `${k} ×${v}`).join(" · ")}
        </div>
      )}
    </div>
  );
}
