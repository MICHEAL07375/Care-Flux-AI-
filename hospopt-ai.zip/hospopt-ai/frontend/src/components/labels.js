export const LABELS = {
  beds: "General beds", icu: "ICU", er: "Emergency dept", or: "Operating rooms",
  nurses: "Nurses", doctors: "Doctors",
};
