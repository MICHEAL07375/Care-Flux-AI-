import { useEffect, useRef, useState } from "react";
import { Download, RefreshCw, RotateCcw, Upload } from "lucide-react";
import { api, BASE } from "../api";
import { DEFAULT_SCENARIO } from "../constants.js";

const MAIN = [
  ["general_beds", "General beds"], ["icu_beds", "ICU beds"], ["doctors", "Doctors"],
  ["nurses", "Nurses"], ["operating_rooms", "Operating rooms"], ["er_capacity", "ER visits/day cap."],
];
const POLICY = [
  ["emergency_reserve_pct", "Emergency reserve (0–0.5)"], ["stepdown_beds_free", "Step-down beds free"],
  ["overflow_icu_pct", "Overflow ICU (share)"], ["regional_transfer_max", "Max regional transfers"],
  ["nurse_callin_pool", "Nurse call-in pool"], ["doctor_callin_pool", "Doctor call-in pool"],
];
const SLIDERS = [
  ["emergency_surge_pct", "Emergency admissions", "+", "%", 60],
  ["flu_season_pct", "Flu-season pressure", "+", "%", 50],
  ["staff_absence_pct", "Staff absence", "−", "%", 30],
  ["beds_out_of_service", "Ward beds out of service", "−", "", 30],
  ["icu_beds_out_of_service", "ICU beds out of service", "−", "", 10],
];

export default function Controls({ resources, horizon, setHorizon, scenario, setScenario, onChanged, onError }) {
  const [draft, setDraft] = useState({});
  const [busy, setBusy] = useState(false);
  const fileRef = useRef(null);

  useEffect(() => {
    if (resources) setDraft(Object.fromEntries([...MAIN, ...POLICY].map(([k]) => [k, String(resources[k])])));
  }, [resources]);

  const run = async (fn) => {
    setBusy(true);
    try { await fn(); onChanged(); } catch (e) { onError(e); } finally { setBusy(false); }
  };

  const apply = () => {
    const patch = {};
    for (const [k] of [...MAIN, ...POLICY]) {
      const v = Number(draft[k]);
      if (draft[k] !== "" && !Number.isNaN(v) && v !== resources[k]) patch[k] = v;
    }
    if (Object.keys(patch).length) run(() => api.saveResources(patch));
  };

  const field = ([k, label]) => (
    <label className="fld" key={k}>{label}
      <input type="number" step="any" value={draft[k] ?? ""} onChange={(e) => setDraft({ ...draft, [k]: e.target.value })} />
    </label>
  );
  const set = (k, v) => setScenario({ ...scenario, [k]: Number(v) });

  return (
    <div className="col">
      <div className="card">
        <h2>Current resources</h2>
        {MAIN.map(field)}
        <details>
          <summary>Policy &amp; levers</summary>
          {POLICY.map(field)}
        </details>
        <button className="btn primary" onClick={apply} disabled={busy || !resources}>Apply resources</button>
      </div>

      <div className="card">
        <h2>Forecast period</h2>
        <div className="seg">
          {[[1, "24 hours"], [3, "3 days"], [7, "7 days"]].map(([h, l]) => (
            <button key={h} className={`btn ${horizon === h ? "on" : ""}`} onClick={() => setHorizon(h)}>{l}</button>
          ))}
        </div>
      </div>

      <div className="card">
        <h2>Scenario simulation</h2>
        <div className="seg">
          <button className="btn" onClick={() => setScenario({ ...DEFAULT_SCENARIO, emergency_surge_pct: 20 })}>Emergency +20%</button>
          <button className="btn" onClick={() => setScenario({ ...DEFAULT_SCENARIO, flu_season_pct: 15, staff_absence_pct: 10 })}>Flu + staff −10%</button>
          <button className="btn" onClick={() => setScenario(DEFAULT_SCENARIO)}>Reset</button>
        </div>
        {SLIDERS.map(([k, label, sign, unit, max]) => (
          <div className="sl" key={k}>
            <div className="row"><span>{label}</span><b>{scenario[k] ? sign : ""}{scenario[k]}{unit}</b></div>
            <input type="range" min="0" max={max} step="1" value={scenario[k]} onChange={(e) => set(k, e.target.value)} />
          </div>
        ))}
      </div>

      <div className="card">
        <h2>Data &amp; model</h2>
        <div className="seg">
          <button className="btn" disabled={busy} onClick={() => fileRef.current?.click()}><Upload size={14} /> Upload CSV</button>
          <a className="btn" href={`${BASE}/api/data/export`}><Download size={14} /> Export</a>
        </div>
        <div className="seg">
          <button className="btn" disabled={busy} onClick={() => run(api.retrain)}><RefreshCw size={14} /> Retrain</button>
          <button className="btn" disabled={busy} onClick={() => run(api.reset)}><RotateCcw size={14} /> Synthetic</button>
        </div>
        <input ref={fileRef} type="file" accept=".csv,text/csv" hidden
          onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ""; if (f) run(() => api.upload(f)); }} />
        <div className="small mu">CSV needs: date, beds_occupied, icu_occupied, emergency_cases, or_hours_used (≥ 60 days).</div>
      </div>
    </div>
  );
}
