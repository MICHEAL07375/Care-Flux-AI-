const COLOR = { OK: "var(--ok)", HIGH: "var(--hi)", CRITICAL: "var(--cr)" };
const ICON = { beds: "🛏", icu: "🚑", er: "🚨", or: "🏥", nurses: "👩‍⚕️", doctors: "👨‍⚕️" };
const UNIT = { or: "h" };

export default function Kpis({ kpis, asOf }) {
  return (
    <div>
      <h2>Current status · {asOf}</h2>
      <div className="kpis">
        {kpis.map((k) => (
          <div className="card kpi" key={k.key}>
            <small>{ICON[k.key]} {k.label}{k.key === "nurses" || k.key === "doctors" ? " needed" : ""}</small>
            <b>{Math.round(k.util * 100)}%</b>
            <div className="bar"><i style={{ width: `${Math.min(100, k.util * 100)}%`, background: COLOR[k.status] }} /></div>
            <small>{k.value}{UNIT[k.key] || ""} / {k.capacity}{UNIT[k.key] || ""} </small>{" "}
            <span className={`pill ${k.status}`}>{k.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
