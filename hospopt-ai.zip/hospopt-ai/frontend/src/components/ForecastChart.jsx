import {
  Area, CartesianGrid, ComposedChart, Legend, Line, ReferenceLine,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";

const TABS = [["icu", "ICU"], ["beds", "General beds"], ["er", "Emergency"], ["or", "OR hours"]];
const capacityOf = (key, r) =>
  ({ icu: r.icu_beds, beds: r.general_beds, er: r.er_capacity, or: r.operating_rooms * r.or_hours_per_room })[key];
const short = (d) => d.slice(5);

export default function ForecastChart({ history, sim, metric, setMetric, model }) {
  if (!history || !sim) return null;
  const sc = sim.scenario, base = sim.baseline;
  const cap = capacityOf(metric, sc.resources);
  const hist = history.series[metric];
  const fc = sc.forecast.series[metric];
  const bs = base.forecast.series[metric].values;
  const showBase = !sc.scenario || Object.values(sc.scenario).some((v) => v !== 0);

  const rows = history.dates.map((d, i) => ({ label: short(d), actual: hist[i] }));
  const last = rows[rows.length - 1];
  last.forecast = last.actual; last.baseline = last.actual; last.low = last.actual; last.span = 0;
  sc.forecast.dates.forEach((d, i) => rows.push({
    label: short(d), forecast: fc.values[i], baseline: bs[i],
    low: fc.lower[i], span: +(fc.upper[i] - fc.lower[i]).toFixed(2),
  }));

  const all = [cap, ...hist, ...fc.values, ...fc.upper];
  const lo = Math.floor(Math.min(...hist, ...fc.lower) * 0.9);
  const hi = Math.ceil(Math.max(...all) * 1.08);
  const m = model?.metrics?.[metric];

  return (
    <div className="card">
      <h2>AI demand forecast</h2>
      <div className="tabs">
        {TABS.map(([k, l]) => (
          <button key={k} className={`btn ${metric === k ? "on" : ""}`} onClick={() => setMetric(k)}>{l}</button>
        ))}
      </div>
      <div style={{ width: "100%", height: 300 }}>
        <ResponsiveContainer>
          <ComposedChart data={rows} margin={{ top: 8, right: 16, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#8884" />
            <XAxis dataKey="label" tick={{ fontSize: 11 }} />
            <YAxis domain={[lo, hi]} tick={{ fontSize: 11 }} />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="low" stackId="band" stroke="none" fill="transparent" legendType="none" name="low" />
            <Area type="monotone" dataKey="span" stackId="band" stroke="none" fill="#0e7c86" fillOpacity={0.18} name="80% band" />
            <ReferenceLine y={cap} stroke="#c62828" strokeDasharray="4 4" label={{ value: `capacity ${cap}`, fill: "#c62828", fontSize: 11, position: "insideTopLeft" }} />
            <Line type="monotone" dataKey="actual" name="History" stroke="#0e7c86" strokeWidth={2.5} dot={false} />
            {showBase && <Line type="monotone" dataKey="baseline" name="Baseline forecast" stroke="#8a97a6" strokeWidth={2} strokeDasharray="2 4" dot={false} />}
            <Line type="monotone" dataKey="forecast" name={showBase ? "Scenario forecast" : "Forecast"} stroke="#e08a00" strokeWidth={2.5} strokeDasharray="6 4" dot={{ r: 2 }} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      {m && (
        <div className="small mu">
          Backtest (3 rolling 7-day origins): MAE {m.mae} · MAPE {m.mape_pct}% · {m.improvement_vs_naive_pct}% better than seasonal-naive.
        </div>
      )}
    </div>
  );
}
