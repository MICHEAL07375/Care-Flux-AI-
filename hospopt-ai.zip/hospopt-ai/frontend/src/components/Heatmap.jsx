import { LABELS } from "./labels.js";

const BG = { OK: "var(--ok)", HIGH: "var(--hi)", CRITICAL: "var(--cr)" };
const status = (u) => (u >= 0.95 ? "CRITICAL" : u >= 0.85 ? "HIGH" : "OK");

export default function Heatmap({ result }) {
  const util = result.forecast.utilization;
  const plans = result.plans;
  return (
    <div className="card">
      <h2>Predicted utilisation heatmap</h2>
      <div className="tw">
        <table className="heat">
          <thead>
            <tr>
              <th>Resource</th>
              {plans.map((p) => <th key={p.date} style={{ textAlign: "center" }}>{p.day === 1 ? "Tomorrow" : `${p.weekday} ${p.date.slice(8)}`}</th>)}
            </tr>
          </thead>
          <tbody>
            {Object.keys(LABELS).map((k) => (
              <tr key={k}>
                <td>{LABELS[k]}</td>
                {util[k].map((u, i) => (
                  <td key={i} className="c" style={{ background: BG[status(u)] }}>{Math.round(u * 100)}%</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="small mu" style={{ marginTop: 6 }}>Green &lt; 85% · Amber 85–95% · Red ≥ 95% (nurses/doctors = required ÷ on duty)</div>
    </div>
  );
}
