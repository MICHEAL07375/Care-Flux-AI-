const GAPS = [
  ["icu_without_bed", "ICU patients without a bed"],
  ["reserve_breach_beds", "Beds taken from emergency reserve"],
  ["or_hours_over", "OR hours over limit"],
  ["nurse_gap", "Nurse gap"],
  ["doctor_gap", "Doctor gap"],
];
const ICON = { escalate: "🚨", monitor: "👀", reserve: "🛡️", none: "✅" };

export default function Plan({ result, selected, setSelected }) {
  const idx = selected ?? result.peak_day;
  const p = result.plans[idx];
  const gaps = GAPS.filter(([k]) => p.baseline_gap[k] > 0 || p.after_gap[k] > 0);
  const d = p.demand;
  return (
    <div className="card">
      <h2>✅ Optimized allocation plan</h2>
      <div className="tabs">
        {result.plans.map((q, i) => (
          <button key={q.date} className={`btn ${q.status}t ${idx === i ? "on" : ""}`} onClick={() => setSelected(i)}>
            {q.day === 1 ? "Tomorrow" : `${q.weekday} ${q.date.slice(8)}`}
          </button>
        ))}
      </div>
      <div className="small mu" style={{ marginBottom: 8 }}>
        Predicted demand: ICU {d.icu} · Beds {d.beds} · ER {d.er}/day · OR {d.or}h ·
        staff needed: {p.staff_required.nurses} nurses, {p.staff_required.doctors} doctors ·{" "}
        <span className={`pill ${p.status}`}>{p.status}</span> · solver {p.solver}
      </div>
      <div className="two">
        <div>
          <h2>Recommended actions</h2>
          <ul className="clean">
            {p.actions.map((a, i) => (
              <li key={i}>
                {ICON[a.type] || "✓"} {a.text}
                <span className="why">Why: {a.reason}</span>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2>Constraint check (after plan)</h2>
          <ul className="clean">
            {p.constraints.map((c) => (
              <li key={c.name} className={c.ok ? "" : "bad"}>
                {c.ok ? "✓" : "✗"} {c.name}
                <span className="why">{c.lhs} ≤ {c.rhs} {c.unit}{c.binding ? " · binding" : ""}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <h2 style={{ marginTop: 14 }}>Impact of the plan</h2>
      {gaps.length === 0 ? (
        <div className="ok">No shortfalls on this day even without intervention.</div>
      ) : (
        <div className="tw">
          <table>
            <thead><tr><th>Shortfall</th><th>Do nothing</th><th>With plan</th></tr></thead>
            <tbody>
              {gaps.map(([k, l]) => (
                <tr key={k}><td>{l}</td><td className="bad">{p.baseline_gap[k]}</td><td className={p.after_gap[k] > 0 ? "bad" : "ok"}>{p.after_gap[k]}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
