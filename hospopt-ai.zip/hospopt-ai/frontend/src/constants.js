export const DEFAULT_SCENARIO = {
  emergency_surge_pct: 0, flu_season_pct: 0, staff_absence_pct: 0,
  beds_out_of_service: 0, icu_beds_out_of_service: 0,
};
